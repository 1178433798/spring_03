package zrj.shiyan7.fuel;

public class Gasoline implements Fuel{
    @Override
    public void fuel() {
        System.out.println("Gasoline");
    }
}
