package zrj.shiyan7.fuel;

public class DieselOil implements Fuel{
    @Override
    public void fuel() {
        System.out.println("DieselOil");
    }
}
