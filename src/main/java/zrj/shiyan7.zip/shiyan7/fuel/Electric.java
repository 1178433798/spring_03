package zrj.shiyan7.fuel;

public class Electric implements Fuel{
    @Override
    public void fuel() {
        System.out.println("Electric");
    }
}
