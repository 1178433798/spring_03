package zrj.shiyan7.fuel;

public interface Fuel {
    public void fuel();
}
