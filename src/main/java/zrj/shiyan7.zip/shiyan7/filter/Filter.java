package zrj.shiyan7.filter;

public interface Filter {
    public void doFilter1();
}
