package zrj.shiyan7.filter;

public class CutoutFilter implements Filter{
    @Override
    public void doFilter1() {
        System.out.println("CutoutFilter");
    }
}
