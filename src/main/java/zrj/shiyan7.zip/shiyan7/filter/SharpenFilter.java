package zrj.shiyan7.filter;

public class SharpenFilter implements Filter{
    @Override
    public void doFilter1() {
        System.out.println("SharpenFilter");
    }
}
