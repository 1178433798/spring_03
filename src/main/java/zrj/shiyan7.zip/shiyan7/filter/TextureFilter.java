package zrj.shiyan7.filter;

public class TextureFilter implements Filter{
    @Override
    public void doFilter1() {
        System.out.println("TextureFilter");
    }
}
