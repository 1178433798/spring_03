package zrj.shiyan7.photoApp;

public class GIFPhotoApp extends PhotoApp{
    @Override
    public void Revision() {
        System.out.println("GIFPhotoApp");
        filter.doFilter1();
    }
}
