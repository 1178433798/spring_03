package zrj.shiyan7.structure;

public class Hatchback implements Structure{

    @Override
    public void structure() {
        System.out.println("Hatchback");
    }
}
