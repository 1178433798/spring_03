package zrj.shiyan7.structure;

public  interface Structure {
    public void structure();
}
