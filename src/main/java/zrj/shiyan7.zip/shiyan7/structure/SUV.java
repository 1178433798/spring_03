package zrj.shiyan7.structure;

public class SUV implements Structure{
    @Override
    public void structure() {
        System.out.println("SUV");
    }
}
