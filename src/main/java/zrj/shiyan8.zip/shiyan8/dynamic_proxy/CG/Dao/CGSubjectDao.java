package zrj.shiyan8.dynamic_proxy.CG.Dao;

import zrj.shiyan8.dynamic_proxy.domain.entity.User;

public interface CGSubjectDao {
    public User queryById(Long id);
}
