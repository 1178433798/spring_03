package zrj.shiyan8.dynamic_proxy.CG;

public class Student {
    public void handOut() {
        System.out.println("学生交作业。");
    }
}
