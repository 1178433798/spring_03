package zrj.shiyan8.dynamic_proxy.CG;

import zrj.shiyan8.dynamic_proxy.domain.entity.User;

import java.util.ArrayList;
import java.util.List;

public class UserList {
    public static List<User> list=new ArrayList<>();
}
