package zrj.shiyan8;

public abstract class Component {

    abstract public void AntiVirus();

    abstract public Component add(Component component);

}
