package zrj.shiyan6;

public class BinarySearch {
    public void binarySearch(int[] arr,int pt){
        System.out.println("binarySearch");
    }
}
