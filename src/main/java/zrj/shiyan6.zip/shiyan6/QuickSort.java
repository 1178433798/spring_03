package zrj.shiyan6;

public class QuickSort {
    public void quickSort(int[] arr){
        System.out.println("QuickSort");
    }
}
