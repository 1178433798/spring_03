package zrj.shiyan6;

public interface DataOperation {
     public void Sort(int[] arr);
     public void search(int[] arr,int pt);

}
