package zrj.shiyan6;

import org.springframework.stereotype.Component;

@Component
public class test {

    public void log(){
        System.out.println("aaaa");
    }

}
